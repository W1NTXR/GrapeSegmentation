# Grape Segmentation > 2023-04-16 7:20pm
https://universe.roboflow.com/uno-heomx/grape-segmentation-ya3hj

Provided by a Roboflow user
License: CC BY 4.0

